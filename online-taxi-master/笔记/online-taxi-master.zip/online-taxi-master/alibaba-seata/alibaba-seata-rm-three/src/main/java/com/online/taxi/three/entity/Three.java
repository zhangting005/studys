package com.online.taxi.three.entity;

import lombok.Data;

@Data
public class Three {
	
	private Integer id;
	
	private String name;
}

package com.online.taxi.one.entity;

import lombok.Data;

@Data
public class One {
	
	private Integer id;
	
	private String name;
}

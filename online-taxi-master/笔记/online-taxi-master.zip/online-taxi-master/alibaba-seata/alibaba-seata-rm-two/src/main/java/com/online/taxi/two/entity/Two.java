package com.online.taxi.two.entity;

import lombok.Data;

@Data
public class Two {
	
	private Integer id;
	
	private String name;
}

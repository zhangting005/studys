package com.online.taxi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiListenOrderApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApiListenOrderApplication.class, args);
	}

}

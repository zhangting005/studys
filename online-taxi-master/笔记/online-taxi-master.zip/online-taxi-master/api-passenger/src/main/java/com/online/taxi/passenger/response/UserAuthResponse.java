package com.online.taxi.passenger.response;

import lombok.Data;

@Data
public class UserAuthResponse {
	
	private String token;
}

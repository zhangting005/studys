package com.online.taxi.driver.constant;

public class HttpUrlConstants {

	public static final String SERVICE_SMS_URL = "http://service-sms";
	
	public static final String SERVICE_ORDER_URL = "http://service-order";

}

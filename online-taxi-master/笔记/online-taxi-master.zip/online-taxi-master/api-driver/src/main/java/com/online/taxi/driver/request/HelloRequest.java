package com.online.taxi.driver.request;

import lombok.Data;

@Data
public class HelloRequest {
	
	private String name;
	
	private Integer age;
}

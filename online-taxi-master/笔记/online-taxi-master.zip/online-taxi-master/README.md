# online-taxi
网约车项目

# 各个服务端口分配

## api层：

乘客（api-passenger）：9001

## service层

验证码服务（service-verification-code）：8001

乘客用户服务（service-passenger-user）：8002

app更新服务（service-app-update）：8003

订单服务（service-order）：8004

订单派单服务（service-order-dispatch）：8005

钱包服务（service-wallet）：8006

短信服务（service-sms）：8007

网关（online-taxi-gateway）：9000


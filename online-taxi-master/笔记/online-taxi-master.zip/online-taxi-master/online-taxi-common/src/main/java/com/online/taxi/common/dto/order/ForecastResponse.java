package com.online.taxi.common.dto.order;

import lombok.Data;
/**
 * 
 * @author yueyi2019
 *
 */
@Data
public class ForecastResponse {
	
	private Double price;
}

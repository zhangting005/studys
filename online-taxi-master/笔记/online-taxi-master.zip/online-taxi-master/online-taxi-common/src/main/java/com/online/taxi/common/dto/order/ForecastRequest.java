package com.online.taxi.common.dto.order;
/**
 * 
 * @author yueyi2019
 *
 */
public class ForecastRequest extends BaseOrder {
	
}

package com.online.taxi.common.dto.appUpdate;

import com.online.taxi.common.entity.AppVersionUpdate;

public class AppUpdateVersionRequest extends AppVersionUpdate{

}

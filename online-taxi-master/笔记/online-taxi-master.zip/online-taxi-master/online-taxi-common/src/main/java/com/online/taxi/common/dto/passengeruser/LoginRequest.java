package com.online.taxi.common.dto.passengeruser;

import lombok.Data;
/**
 * @author yueyi2019
 */
@Data
public class LoginRequest {

    private String phoneNumber;

}

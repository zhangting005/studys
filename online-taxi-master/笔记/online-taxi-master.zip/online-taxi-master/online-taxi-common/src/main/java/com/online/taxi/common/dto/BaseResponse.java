package com.online.taxi.common.dto;

/**
 * @author yueyi2019
 */
public class BaseResponse {

}

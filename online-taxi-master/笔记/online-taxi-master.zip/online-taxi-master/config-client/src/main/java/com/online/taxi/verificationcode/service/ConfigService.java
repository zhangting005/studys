package com.online.taxi.verificationcode.service;

/**
 * @author yueyi2019
 */
public interface ConfigService {
    /**
     * 测试获取env1
     * @return
     */
    public String getEnv1();

    /**
     * 测试获取env2
     * @return
     */
    public String getEnv2();
}

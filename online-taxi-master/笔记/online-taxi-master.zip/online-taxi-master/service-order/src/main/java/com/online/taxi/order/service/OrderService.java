package com.online.taxi.order.service;

public interface OrderService {
	
	public boolean grab(int orderId, int driverId);
	
}

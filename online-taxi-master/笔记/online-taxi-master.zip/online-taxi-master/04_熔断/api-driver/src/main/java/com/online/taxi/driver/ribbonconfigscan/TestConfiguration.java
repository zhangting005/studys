package com.online.taxi.driver.ribbonconfigscan;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Configuration;

import com.online.taxi.driver.ribbonconfig.RibbonConfiguration;

//@Configuration
//@RibbonClient(name = "service-sms",configuration = RibbonConfiguration.class)
public class TestConfiguration {

}
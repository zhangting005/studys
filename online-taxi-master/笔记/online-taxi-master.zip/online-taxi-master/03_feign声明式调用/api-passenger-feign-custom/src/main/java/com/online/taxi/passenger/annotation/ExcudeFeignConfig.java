package com.online.taxi.passenger.annotation;
public @interface ExcudeFeignConfig {

}
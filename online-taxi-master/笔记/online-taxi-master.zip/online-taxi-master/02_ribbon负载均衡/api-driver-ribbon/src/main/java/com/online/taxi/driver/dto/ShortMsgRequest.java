package com.online.taxi.driver.dto;

import lombok.Data;
/**
 * @author yueyi2019
 */
@Data
public class ShortMsgRequest {
	
	private String phoneNumber;
}

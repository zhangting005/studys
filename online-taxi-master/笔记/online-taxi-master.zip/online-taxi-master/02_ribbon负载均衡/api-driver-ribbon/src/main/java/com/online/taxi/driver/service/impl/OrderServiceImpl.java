package com.online.taxi.driver.service.impl;

import org.springframework.stereotype.Service;

import com.online.taxi.common.dto.order.ForecastRequest;
import com.online.taxi.driver.service.OrderService;
/**
 * 
 * @author yueyi2019
 *
 */
@Service
public class OrderServiceImpl implements OrderService {
	
	
	
	@Override
	public Double forecast(ForecastRequest forecastRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}

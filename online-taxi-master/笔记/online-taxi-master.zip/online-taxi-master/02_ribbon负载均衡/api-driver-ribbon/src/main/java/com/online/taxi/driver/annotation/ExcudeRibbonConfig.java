package com.online.taxi.driver.annotation;

public @interface ExcudeRibbonConfig {

}
